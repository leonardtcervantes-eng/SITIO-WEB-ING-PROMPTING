# NEXO · IA y organización

Sitio web estático en un solo archivo HTML. No necesita compilación ni dependencias externas para funcionar.

## Publicarlo con GitHub Pages

1. Sube `index.html` a la raíz de un repositorio de GitHub.
2. En el repositorio, abre **Settings → Pages**.
3. Elige publicar desde la rama principal y la carpeta raíz.
4. Guarda la configuración; GitHub mostrará la dirección pública del sitio en esa misma sección.
